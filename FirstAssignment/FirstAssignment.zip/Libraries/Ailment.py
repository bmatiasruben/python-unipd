ailment = [
    'freeze',
    'paralyze',
    'burn',
    'poison',
    'sleep'
]
